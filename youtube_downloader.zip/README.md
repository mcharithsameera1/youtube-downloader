# YouTube Downloader (GUI)

A simple desktop YouTube video downloader using Python, `yt-dlp`, and `tkinter`.

## Features
- Download videos in best quality
- Easy GUI interface
- Auto saves to `downloads/` folder

## Requirements
- Python 3.7+
- yt-dlp (`pip install yt-dlp`)

## Usage
1. Clone the repo
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `python gui_youtube_downloader.py`

## Note
Downloads are stored in a `downloads/` folder in the project directory.

⚠️ **Make sure to comply with YouTube's terms of service when downloading content.**
